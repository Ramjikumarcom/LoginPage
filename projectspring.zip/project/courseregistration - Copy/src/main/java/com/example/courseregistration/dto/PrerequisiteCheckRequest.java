package com.example.courseregistration.dto;
import lombok.Data;
import java.util.List;

@Data
public class PrerequisiteCheckRequest {
    private List<Long> selectedCourseIds;
}