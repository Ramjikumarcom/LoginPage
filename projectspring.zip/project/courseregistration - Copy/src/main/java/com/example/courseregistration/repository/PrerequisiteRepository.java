package com.example.courseregistration.repository;

import com.example.courseregistration.entity.Prerequisite;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PrerequisiteRepository extends JpaRepository<Prerequisite, Long> {
    List<Prerequisite> findByCourse_CourseId(Long courseId);
}
