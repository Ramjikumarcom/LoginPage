package com.example.courseregistration.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class PrerequisiteDTO {
    private Long courseId;
    private Long prerequisiteCourseId;
}
