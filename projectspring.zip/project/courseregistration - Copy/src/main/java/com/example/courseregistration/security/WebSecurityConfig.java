package com.example.courseregistration.security;

public class WebSecurityConfig {
}
