package com.example.courseregistration.controller;// src/main/java/com/example/courseregistration/controller/CourseController.java

import com.example.courseregistration.dto.PrerequisiteCheckRequest;
import com.example.courseregistration.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CourseController {

    @Autowired
    private CourseService courseService;

    @PostMapping("/courses/check-prerequisite")
    public ResponseEntity<Map<String, Object>> checkPrerequisite(
            @RequestParam Long courseId,
            @RequestBody PrerequisiteCheckRequest request) {
        return ResponseEntity.ok(courseService.checkPrerequisite(courseId, request.getSelectedCourseIds()));
    }

    @PostMapping("/courses/validate-selection")
    public ResponseEntity<Map<String, Object>> validateSelection(
            @RequestBody List<Long> selectedCourseIds) {
        return ResponseEntity.ok(courseService.validateFinalSelection(selectedCourseIds));  // Changed this line
    }

    @GetMapping("/courses/selected")
    public ResponseEntity<Map<String, Object>> getSelectedCourses(
            @RequestParam List<Long> selectedCourseIds) {
        return ResponseEntity.ok(courseService.getSelectedCourses(selectedCourseIds));
    }
}