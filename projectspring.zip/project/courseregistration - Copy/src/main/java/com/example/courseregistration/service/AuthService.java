package com.example.courseregistration.service;

import com.example.courseregistration.dto.*;
import com.example.courseregistration.entity.Users;
import com.example.courseregistration.exception.AuthException;
import com.example.courseregistration.repository.UserRepository;
import com.example.courseregistration.security.JwtUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    public RegisterResponse register(RegisterRequest request) {
        log.info("Processing registration for email: {}", request.getEmail());

        // Validate request
        if (request.getEmail() == null || request.getEmail().trim().isEmpty()) {
            throw new AuthException("Email cannot be empty");
        }
        if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
            throw new AuthException("Password cannot be empty");
        }
        if (request.getName() == null || request.getName().trim().isEmpty()) {
            throw new AuthException("Name cannot be empty");
        }

        // Check if user exists
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new AuthException("Email already registered");
        }

        try {
            Users user = new Users();
            user.setEmail(request.getEmail().trim());
            user.setName(request.getName().trim());
            user.setPassword(passwordEncoder.encode(request.getPassword()));

            userRepository.save(user);
            log.info("Successfully registered user with email: {}", request.getEmail());

            String token=jwtUtil.generateToken(request.getEmail());

            return new RegisterResponse(true, "Registration successful", token);
        } catch (Exception e) {
            log.error("Error while registering user: ", e);
            throw new AuthException("Error during registration: " + e.getMessage());
        }
    }

    public LoginResponse login(LoginRequest request) {
        log.info("Processing login for email: {}", request.getEmail());

        // Validate request
        if (request.getEmail() == null || request.getEmail().trim().isEmpty()) {
            throw new AuthException("Email cannot be empty");
        }
        if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
            throw new AuthException("Password cannot be empty");
        }

        try {
            // Find user by email
            Users user = userRepository.findByEmail(request.getEmail())
                    .orElseThrow(() -> new AuthException("Invalid email or password"));

            // Verify password
            if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
                throw new AuthException("Invalid email or password");
            }

            // Generate JWT token
            String token = jwtUtil.generateToken(user.getEmail());

            log.info("Successfully logged in user with email: {}", request.getEmail());

            return new LoginResponse(
                    true,
                    "Login successful",
                    token,
                    user.getName()
            );
        } catch (AuthException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error while logging in user: ", e);
            throw new AuthException("Error during login: " + e.getMessage());
        }
    }
}
