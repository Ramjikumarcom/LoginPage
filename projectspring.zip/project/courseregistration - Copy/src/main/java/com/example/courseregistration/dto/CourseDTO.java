package com.example.courseregistration.dto;

import lombok.*;

import java.util.Date;
import java.util.List;

@Data
@Getter

@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString

public class CourseDTO {
    private Long courseId;
    private String courseName;
    private String courseDescription;
    private String facultyName;
    private Float courseCredit;
    private Integer capacity;
    private Date year;
    private Integer term;
    private List<Long> prerequisiteCourseIds;
}