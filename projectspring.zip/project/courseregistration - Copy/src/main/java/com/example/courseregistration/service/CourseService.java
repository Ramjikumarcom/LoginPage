package com.example.courseregistration.service;
import com.example.courseregistration.dto.CourseDTO;
import com.example.courseregistration.entity.Course;
import com.example.courseregistration.entity.Prerequisite;
import com.example.courseregistration.exception.CourseNotFoundException;
import com.example.courseregistration.repository.CourseRepository;
import com.example.courseregistration.repository.PrerequisiteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class CourseService {
    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private PrerequisiteRepository prerequisiteRepository;

    public Map<String, Object> checkPrerequisite(Long courseToSelect, List<Long> alreadySelectedCourses) {
        Map<String, Object> response = new HashMap<>();

        // Check maximum course limit
        if (alreadySelectedCourses.size() >= 6) {
            response.put("canSelect", false);
            response.put("message", "Maximum 6 courses can be selected");
            return response;
        }
//        **************

//        **************
        Course course = courseRepository.findById(courseToSelect)
                .orElseThrow(() -> new CourseNotFoundException("Course not found"));

        List<Prerequisite> prerequisites = prerequisiteRepository.findByCourse_CourseId(courseToSelect);

        // Check if course is already selected
        if (alreadySelectedCourses.contains(courseToSelect)) {
            response.put("canSelect", false);
            response.put("message", "Course already selected");
            return response;
        }

        if (prerequisites.isEmpty()) {
            response.put("canSelect", true);
            response.put("message", String.format("No prerequisites required. Selected courses: %d/6 (Minimum 4 required)",
                    alreadySelectedCourses.size() + 1));
            return response;
        }

        List<String> missingPrerequisites = new ArrayList<>();
        for (Prerequisite prereq : prerequisites) {
            if (!alreadySelectedCourses.contains(prereq.getPrerequisiteCourse().getCourseId())) {
                missingPrerequisites.add(prereq.getPrerequisiteCourse().getCourseName());
            }
        }

        boolean canSelect = missingPrerequisites.isEmpty();
        String message = canSelect ?
                String.format("All prerequisites met. Selected courses: %d/6 (Minimum 4 required)",
                        alreadySelectedCourses.size() + 1) :
                "Missing prerequisites: " + String.join(", ", missingPrerequisites);

        response.put("canSelect", canSelect);
        response.put("message", message);
        return response;
    }

    public Map<String, Object> validateFinalSelection(List<Long> selectedCourseIds) {
        Map<String, Object> response = new HashMap<>();

        // Check minimum and maximum limits
        if (selectedCourseIds.size() < 4) {
            response.put("valid", false);
            response.put("message", "Minimum 4 courses must be selected. Currently selected: " +
                    selectedCourseIds.size());
            return response;
        }

        if (selectedCourseIds.size() > 6) {
            response.put("valid", false);
            response.put("message", "Maximum 6 courses can be selected. Currently selected: " +
                    selectedCourseIds.size());
            return response;
        }

        List<Course> selectedCourses = courseRepository.findAllById(selectedCourseIds);
        List<String> errors = new ArrayList<>();

        // Validate prerequisites for each course
        for (Course course : selectedCourses) {
            List<Prerequisite> prerequisites = prerequisiteRepository
                    .findByCourse_CourseId(course.getCourseId());

            for (Prerequisite prereq : prerequisites) {
                if (!selectedCourseIds.contains(prereq.getPrerequisiteCourse().getCourseId())) {
                    errors.add(String.format("Course '%s' requires '%s' as prerequisite",
                            course.getCourseName(),
                            prereq.getPrerequisiteCourse().getCourseName()));
                }
            }
        }



        boolean isValid = errors.isEmpty();
        response.put("valid", isValid);
        response.put("message", isValid ?
                String.format("All selections are valid. Total courses selected: %d", selectedCourses.size()) :
                String.join("; ", errors));
        response.put("selectedCourses", selectedCourses.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList()));

        return response;
    }


    // Add the convertToDTO method
    private CourseDTO convertToDTO(Course course) {
        CourseDTO dto = new CourseDTO();
        dto.setCourseId(course.getCourseId());
        dto.setCourseName(course.getCourseName());
        dto.setCourseDescription(course.getCourseDescription());
        dto.setFacultyName(course.getFacultyName());
        dto.setCourseCredit(course.getCourseCredit());
        dto.setCapacity(course.getCapacity());
        dto.setYear(course.getYear());
        dto.setTerm(course.getTerm());

        // Convert prerequisites to IDs
        List<Long> prerequisiteIds = course.getPrerequisites().stream()
                .map(prereq -> prereq.getPrerequisiteCourse().getCourseId())
                .collect(Collectors.toList());
        dto.setPrerequisiteCourseIds(prerequisiteIds);

        return dto;
    }
    public Map<String, Object> getSelectedCourses(List<Long> selectedCourseIds) {
        Map<String, Object> response = new HashMap<>();

        List<Course> courses = courseRepository.findAllById(selectedCourseIds);
        List<CourseDTO> courseDTOs = courses.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());

        response.put("selectedCourses", courseDTOs);
        response.put("totalSelected", courseDTOs.size());
        response.put("remainingSlots", 6 - courseDTOs.size());

        if(courseDTOs.size() < 4) {
            response.put("message", String.format("Need %d more courses to meet minimum requirement", 4 - courseDTOs.size()));
        } else {
            response.put("message", "Valid course selection");
        }

        return response;
    }
}
