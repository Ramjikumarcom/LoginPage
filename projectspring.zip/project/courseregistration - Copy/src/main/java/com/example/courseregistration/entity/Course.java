package com.example.courseregistration.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "courses")
@Data
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long courseId;

    @Column(nullable = false)
    private String courseName;

    private String courseDescription;

    @Column(nullable = false)
    private String facultyName;

    private Float courseCredit;
    private Integer capacity;
    private Date year;
    private Integer term;

    @OneToMany(mappedBy = "course")
    private List<Prerequisite> prerequisites;
}