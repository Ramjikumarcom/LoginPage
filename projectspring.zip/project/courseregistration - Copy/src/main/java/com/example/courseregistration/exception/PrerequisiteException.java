package com.example.courseregistration.exception;

public class PrerequisiteException extends RuntimeException {
    public PrerequisiteException(String message) {
        super(message);
    }
}
