CREATE DATABASE  CourseData;

USE CourseData;

CREATE TABLE courses (
                         course_id BIGINT PRIMARY KEY AUTO_INCREMENT,
                        course_code varchar(10) NOT NULL UNIQUE,
                         course_name VARCHAR(255) NOT NULL,
                         course_description TEXT,
                         faculty_name VARCHAR(255) NOT NULL,
                         course_credit FLOAT,
                         capacity INTEGER,
                         year DATE,
                         term INTEGER
);

CREATE TABLE prerequisites (
                               id BIGINT PRIMARY KEY AUTO_INCREMENT,
                               course_id BIGINT,
                               prerequisite_course_id BIGINT,
                               FOREIGN KEY (course_id) REFERENCES courses(course_id),
                               FOREIGN KEY (prerequisite_course_id) REFERENCES courses(course_id)
);
CREATE TABLE users (
                               email varchar(30) KEY not null ,
                               name varchar(30) not null ,
                               password varchar(20) not null
);


INSERT INTO courses (course_code, course_name, course_description, faculty_name, course_credit, capacity, year, term) VALUES
                                                                                                                          ('CS101', 'Introduction to Programming', 'Basic concepts of programming using Java', 'Dr. John Smith', 3.0, 50, '2024-01-15', 1),
                                                                                                                          ('CS102', 'Data Structures', 'Fundamental data structures and algorithms', 'Dr. Sarah Johnson', 3.0, 45, '2024-01-15', 1),
                                                                                                                          ('CS201', 'Database Management', 'Introduction to SQL and database design', 'Prof. Michael Brown', 3.0, 40, '2024-01-15', 1),
                                                                                                                          ('CS202', 'Web Development', 'Full-stack web application development', 'Dr. Emily Davis', 3.0, 35, '2024-01-15', 1),
                                                                                                                          ('CS301', 'Software Engineering', 'Software development lifecycle and methodologies', 'Prof. Robert Wilson', 4.0, 30, '2024-01-15', 2),
                                                                                                                          ('CS302', 'Advanced Programming', 'Advanced concepts in Java programming', 'Dr. Lisa Anderson', 4.0, 25, '2024-01-15', 2),
                                                                                                                          ('CS401', 'Artificial Intelligence', 'Introduction to AI and machine learning', 'Dr. David Lee', 4.0, 30, '2024-01-15', 2),
                                                                                                                          ('CS402', 'Computer Networks', 'Fundamentals of computer networking', 'Prof. Jennifer White', 3.0, 35, '2024-01-15', 2),
                                                                                                                          ('CS403', 'Cloud Computing', 'Cloud architecture and services', 'Dr. James Taylor', 3.0, 30, '2024-01-15', 2),
                                                                                                                          ('CS404', 'Cybersecurity', 'Security principles and practices', 'Prof. Mary Wilson', 4.0, 25, '2024-01-15', 2);


INSERT INTO prerequisites (course_id, prerequisite_course_id) VALUES
-- CS102 (Data Structures) requires CS101 (Intro to Programming)
(2, 1),

-- CS201 (Database Management) requires CS101 (Intro to Programming)
(3, 1),

-- CS202 (Web Development) requires CS101 (Intro to Programming)
(4, 1),

-- CS301 (Software Engineering) requires CS102 (Data Structures) and CS201 (Database Management)
(5, 2),
(5, 3),

-- CS302 (Advanced Programming) requires CS102 (Data Structures)
(6, 2),

-- CS401 (Artificial Intelligence) requires CS302 (Advanced Programming)
(7, 6),

-- CS402 (Computer Networks) requires CS102 (Data Structures)
(8, 2),

-- CS403 (Cloud Computing) requires CS402 (Computer Networks)
(9, 8),

-- CS404 (Cybersecurity) requires CS402 (Computer Networks)
(10, 8);

INSERT INTO users (email, name, password) VALUES
                                                   ('john.doe@gmail.com', 'John Doe', 'password123'),
                                                   ('sarah.smith@gmail.com', 'Sarah Smith', 'sarah2024'),
                                                   ('mike.brown@yahoo.com', 'Michael Brown', 'secure456'),
                                                   ('emma.wilson@gmail.com', 'Emma Wilson', 'emma1234'),
                                                   ('alex.davis@hotmail.com', 'Alex Davis', 'alex2024'),
                                                   ('lisa.taylor@gmail.com', 'Lisa Taylor', 'taylor789'),
                                                   ('david.miller@yahoo.com', 'David Miller', 'david567'),
                                                   ('anna.white@gmail.com', 'Anna White', 'anna2024'),
                                                   ('james.anderson@gmail.com', 'James Anderson', 'james890');
