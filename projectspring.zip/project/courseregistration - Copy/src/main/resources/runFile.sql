USE courseregistration;

SELECT *
FROM courses
WHERE course_id not IN (
    SELECT course_id
    FROM prerequisites
    WHERE prerequisites.prerequisite_course_id = courses.course_id
);
INSERT INTO courses (course_name, course_description, faculty_name, course_credit, capacity) VALUES
                                                                                                 ('Introduction to Programming', 'Basic programming concepts', 'Dr. Smith', 3.0, 30),
                                                                                                 ('Data Structures', 'Advanced data structures', 'Prof. Johnson', 4.0, 25),
                                                                                                 ('Algorithms', 'Algorithm design and analysis', 'Dr. Williams', 4.0, 25),
                                                                                                 ('Database Systems', 'Database concepts and SQL', 'Prof. Davis', 3.0, 30),


                                                                                                 ('Web Development', 'Web technologies and frameworks', 'Dr. Brown', 3.0, 35);

INSERT INTO courses (course_name, course_description, faculty_name, course_credit, capacity) VALUES ('Introduction to Programming', 'Basic programming concepts', 'Dr. Smith', 3.0, 30);