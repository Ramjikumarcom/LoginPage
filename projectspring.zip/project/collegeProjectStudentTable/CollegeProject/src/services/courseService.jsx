// src/services/courseService.js
import axios from 'axios';

const API_URL = 'http://localhost:8080/api/courses';

const getAuthHeader = () => {
    const token = localStorage.getItem('token');
    return {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    };
};

export const courseService = {
    getAllCourses: async () => {
        const response = await axios.get(API_URL, getAuthHeader());
        return response.data;
    },

    checkPrerequisites: async (courseId, selectedCourseIds) => {
        const response = await axios.post(
            `${API_URL}/check-prerequisite?courseId=${courseId}`,
            { selectedCourseIds },
            getAuthHeader()
        );
        return response.data;
    },

    validateSelection: async (selectedCourseIds) => {
        const response = await axios.post(
            `${API_URL}/validate-selection`,
            selectedCourseIds,
            getAuthHeader()
        );
        return response.data;
    }
};