// src/components/course/CourseCard.jsx
import React from 'react';

const CourseCard = ({ course, onSelect, isSelected, disabled }) => {
    return (
        <div className="card mb-3">
            <div className="card-body">
                <h5 className="card-title">{course.courseName}</h5>
                <h6 className="card-subtitle mb-2 text-muted">
                    Professor: {course.facultyName}
                </h6>
                <p className="card-text">{course.courseDescription}</p>
                <div className="d-flex justify-content-between align-items-center">
                    <div>
                        <span className="badge bg-info me-2">
                            Credits: {course.courseCredit}
                        </span>
                        <span className="badge bg-secondary">
                            Capacity: {course.capacity}
                        </span>
                    </div>
                    <button
                        className={`btn ${isSelected ? 'btn-danger' : 'btn-primary'}`}
                        onClick={() => onSelect(course)}
                        disabled={disabled}
                    >
                        {isSelected ? 'Remove' : 'Select'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default CourseCard;