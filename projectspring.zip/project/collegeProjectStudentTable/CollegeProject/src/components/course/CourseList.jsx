// src/components/course/CourseList.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { authService } from '../../services/authService';

function CourseList() {
    const [courses, setCourses] = useState([]);
    const [selectedCourses, setSelectedCourses] = useState([]);
    const [message, setMessage] = useState('');
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        fetchCourses();
    }, []);

    const fetchCourses = async () => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:8080/api/courses', {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            setCourses(response.data);
            setLoading(false);
        } catch (error) {
            setMessage('Error loading courses');
            setLoading(false);
        }
    };

    const handleCourseSelect = async (courseId) => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.post(
                `http://localhost:8080/api/courses/check-prerequisite?courseId=${courseId}`,
                {
                    selectedCourseIds: selectedCourses.map(course => course.courseId)
                },
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            if (response.data.canSelect) {
                const courseToAdd = courses.find(c => c.courseId === courseId);
                setSelectedCourses([...selectedCourses, courseToAdd]);
                setMessage(response.data.message);
            } else {
                setMessage(response.data.message);
            }
        } catch (error) {
            setMessage('Error checking prerequisites');
        }
    };

    const handleCourseDeselect = (courseId) => {
        setSelectedCourses(selectedCourses.filter(course => course.courseId !== courseId));
    };

    if (loading) {
        return (
            <div className="container mt-4 text-center">
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    return (
        <div className="container mt-4">
            <div className="row mb-3">
                <div className="col">
                    <h2>Course Selection</h2>
                    {message && (
                        <div className="alert alert-info alert-dismissible fade show" role="alert">
                            {message}
                            <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    )}
                </div>
                <div className="col-auto">
                    <button
                        className="btn btn-danger"
                        onClick={() => {
                            authService.logout();
                            navigate('/login');
                        }}
                    >
                        Logout
                    </button>
                </div>
            </div>

            <div className="row">
                <div className="col-md-8">
                    <div className="card">
                        <div className="card-header bg-primary text-white">
                            Available Courses
                        </div>
                        <div className="card-body p-0">
                            <table className="table table-hover mb-0">
                                <thead className="table-light">
                                    <tr>
                                        <th>Course Name</th>
                                        <th>Description</th>
                                        <th>Faculty</th>
                                        <th>Credits</th>
                                        <th>Capacity</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {courses.map(course => (
                                        <tr key={course.courseId}>
                                            <td>{course.courseName}</td>
                                            <td>{course.courseDescription}</td>
                                            <td>{course.facultyName}</td>
                                            <td>{course.courseCredit}</td>
                                            <td>{course.capacity}</td>
                                            <td>
                                                <button
                                                    className="btn btn-success btn-sm"
                                                    onClick={() => handleCourseSelect(course.courseId)}
                                                    disabled={selectedCourses.some(c => c.courseId === course.courseId)}
                                                >
                                                    Select
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div className="col-md-4">
                    <div className="card">
                        <div className="card-header bg-success text-white">
                            Selected Courses ({selectedCourses.length}/6)
                        </div>
                        <div className="card-body">
                            {selectedCourses.map(course => (
                                <div key={course.courseId} className="d-flex justify-content-between align-items-center mb-2">
                                    <span>{course.courseName}</span>
                                    <button
                                        className="btn btn-danger btn-sm"
                                        onClick={() => handleCourseDeselect(course.courseId)}
                                    >
                                        Remove
                                    </button>
                                </div>
                            ))}
                            {selectedCourses.length < 4 && (
                                <div className="alert alert-warning mt-3">
                                    Select at least {4 - selectedCourses.length} more courses
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CourseList;