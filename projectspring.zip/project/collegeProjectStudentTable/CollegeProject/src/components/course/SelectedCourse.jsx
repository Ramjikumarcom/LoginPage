import React from 'react';

const SelectedCoursesTable = ({ courses, onDeselect }) => {
    return (
        <table className="table table-hover mb-0">
            <thead className="table-light">
                <tr>
                    <th>Course Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {courses.map(course => (
                    <tr key={course.courseId}>
                        <td>{course.courseName}</td>
                        <td>
                            <button
                                className="btn btn-danger btn-sm"
                                onClick={() => onDeselect(course.courseId)}
                            >
                                Deselect
                            </button>
                        </td>
                    </tr>
                ))}
            </tbody>
        </table>
    );
};

export default SelectedCoursesTable;
